<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso a sua conta - PetS</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>

    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo/estilo-logar.css">
</head>
<body>
    <header><nav>
        <!-- MENU -->
        <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>
        <div class="container-logar">
                <h2 class="bem-vindo">Bem vindo ao PetS</h2>
            <div class="container-caixa1">
                <h2 class="acesso1">Acesse sua conta</h2>
                <input type="text" class="email1" name="email" id="email" tabindex="0" placeholder="Email,CPF ou CNPJ" value="" autofocus="1" autocomplete="username" aria-label="Email,CPF ou CNPJ">
                <input type="password" class="senha1" name="email" id="email" tabindex="0" placeholder="Senha" value="" autofocus="1" autocomplete="username" aria-label="Senha">
                <a href="perfil.php"><button class="entrar1">Entrar</button></a>
            </div>
            <div class="container-caixa2">
                <h2 class="acesso2">Criar sua conta</h2>
                <input type="text" class="email2" name="email" id="email" tabindex="0" placeholder="Email,CPF ou CNPJ" value="" autofocus="1" autocomplete="username" aria-label="Email,CPF ou CNPJ">
                <input type="password" class="senha2" name="email" id="email" tabindex="0" placeholder="Senha" value="" autofocus="1" autocomplete="username" aria-label="Senha">
                <a><button class="criar">Criar conta</button></a>
                <a><button class="criar-ong">Criar conta ONG</button></a>
            </div>
        </div>
    </header>

    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </body>
    </html>