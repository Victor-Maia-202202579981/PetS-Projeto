<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>
    
    <!-- BUSCANDO O ESTILO DO SITE NO ESTILO.CSS -->
    <link rel="stylesheet" href="css/estilo/estilo-perfil.css">
    <!-- LOGO NA ABA DA PÁGINA -->
    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 
</head>
<body>
    <header>
        <!-- LOGO NO CORPO DA PÁGINA 
       <div class="logo">
           <img src="img/icone-letra.png" alt="Logo tipo PetS">
       </div>-->

<!-- NAVEGABILIDADE- USUÁRIO PODE ACESSAR OUTRAS ABAS -->
       <nav>
       <!-- MENU -->
           <ul class="menu">
               <li><a class="logo" src="index.php">PetS</a></li>
               <li><a href="index.php">Home</a></li>
               <li><a href="institucional.php">Institucional</a></li>
               <li><a href="ongs.php">ONGs/Potetores</a></li>
               <li><a href="Denunciar.php">Denunciar</a></li>
           </ul>
           <a><button class="btn-adotar">Adotar</button></a>
           <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
       </nav>
       

    <div class="container-cabecalho">
        <div class="container-caixa">
            <h2 class="portal">Portal de Perfil</h2>
            <img class="imgAvatar" src="img/default-avatar.png" alt="">
            <h3 class="detalhe">Detalhes pessoais</h3>
            <p class="nome">Nome</p>
            <input class="digitar-nome" type="text">
            <p class="email">Email</p>
            <p class="email-usuario">usuário@gmail.com</p>
            <p class="cpf-cnpj">CPF/CNPJ</p>
            <p class="cpf">XXX.XXX.XXX-XX</p>
            <p class="senha">Senha</p>
            <a><button class="btn-alterar">Alterar senha</button></a>
                </header>
    </div>
                    <!-- RODAPÉ DA PÁGINA-->
                    <div class="conteiner-buttom">
                        <img src="img/logo/icone-rodape-logo.png" alt="">
                        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
                        <h3>Institucional</h3>
                        <h4 class="conteiner-item1">Sobre o PetS</h4>
                        <h4 class="conteiner-item2">FAQ</h4>
                    </div>
    </body>