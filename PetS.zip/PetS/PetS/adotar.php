<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adotar</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>
    
    <!-- BUSCANDO O ESTILO DO SITE NO ESTILO.CSS -->
    <link rel="stylesheet" href="css/estilo/estilo-adotar.css">
    <!-- LOGO NA ABA DA PÁGINA -->
    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 
</head>
<body>
    <header>
        <!-- LOGO NO CORPO DA PÁGINA 
       <div class="logo">
           <img src="img/icone-letra.png" alt="Logo tipo PetS">
       </div>-->

<!-- NAVEGABILIDADE- USUÁRIO PODE ACESSAR OUTRAS ABAS -->
       <nav>
       <!-- MENU -->
           <ul class="menu">
               <li><a class="logo" src="index.php">PetS</a></li>
               <li><a href="index.php">Home</a></li>
               <li><a href="institucional.php">Institucional</a></li>
               <li><a href="ongs.php">ONGs/Potetores</a></li>
               <li><a href="Denunciar.php">Denunciar</a></li>
           </ul>
           <a><button class="btn-adotar">Adotar</button></a>
           <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
       </nav>
       
    </header>


       <!-- CARD COM OS ANIMAIS PARA ADOÇÃO -->
    <div class="conteiner-adotar">
        <h2>Adoção</h2>
        <p class="conteiner-adotar-p" >Abaixo estão essas fofuras que estão disponíveis e a procura de um lar.</p>
    
            <div class="card-adotar-1">
                <img class="imgBx1" src="img/adotar/exemplo-1.jpg" alt="">
                <p class="card-adotar-p-1">ONG Peludinhos - AM</p>
                <h3><br> Pipoca, feminino</h3>
                <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario">Adotar</button></a>
            </div>
       
            <div class="card-adotar-2">
                    <img class="imgBx2" src="img/adotar/exemplo-2.jpeg" alt="">
                    <p class="card-adotar-p-2">Maria Fátima - AM</p>
                    <h3><br> Mel, feminino</h3>
                    <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario2">Adotar</button></a>
            </div>


            <div class="card-adotar-3">
                    <img class="imgBx3" src="img/adotar/exemplo-3.jpeg" alt="">
                    <p class="card-adotar-p-3">ONG CATS LOVERS- AM</p>
                    <h3><br>Rosa, Perola e Nana, Feminino</h3>
                    <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario3">Adotar</button></a>
            </div>

            <div class="card-adotar-4">
                <img class="imgBx4" src="img/adotar/exemplo-4.jpg" alt="">
                <p class="card-adotar-p-4">ONG APAM - AM</p>
                <h3><br>Peteca, feminino</h3>
                <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario4">Adotar</button></a>
            </div>

            <div class="card-adotar-5">
                <img class="imgBx5" src="img/adotar/xexmplo-5.jpeg" alt="">
                <p class="card-adotar-p-5">Duda - AM</p>
                <h3><br>Lepo Lepo, masculino</h3>
                <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario5">Adotar</button></a>
            </div>

            <div class="card-adotar-6">
                <img class="imgBx6" src="img/adotar/exemplo-06.jpg" alt="">
                <p class="card-adotar-p-6">ONG APAM - AM</p>
                <h3><br>Rosita, Feminino</h3>
                <a href="Formulário-adotar.html"><button class="btn-adotar-para-formulario6">Adotar</button></a>
            </div>

            <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>

    </div>
    
</body>
</html>