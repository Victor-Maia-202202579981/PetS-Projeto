<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
      </style>
    <title>Institucional</title>
    <!-- LOGO NA ABA DA PÁGINA -->
    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 
    <link rel="stylesheet" href="css/estilo/estilo-institucional.css">
</head>
<body>
    <header>
        <nav>
            <!-- MENU -->
            <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>
    </header>
    
    <div class="conteirner-base">
        <div class="conteiner-guia">
            <ul><h3>Guia</h3></ul>
            <li><a href="#sobrePets"><h4 class="conteiner-guia-item1">Sobre o PetS</h4></a></li>
            <li><a href="#comoPets"><h4 class="conteiner-guia-item2" >Como funciona?</h4></a></li>
            <li><a href="#comoAdotar"><h4 class="conteiner-guia-item3">Como adotar?</h4></a></li>
        </div>
        <h2 id="sobrePets" class="conteirner-base-titulo1">SOBRE A PETS</h2>
        <p class="conteirner-base-p1">Somos um projeto voltado para pets que visa a adoção para nosso companheiros. O objetivo do nosso site de doação de animais é facilitar a adoção responsável de animais de estimação por pessoas que estão interessadas em dar um lar amoroso a esses animais. Ele será feito com o intuito de conectar animais que estão em abrigos, resgates ou organizações de resgate de animais com indivíduos ou famílias dispostas a adotar um animal de estimação. Nossos principais objetivos são: Promover Adoções Responsáveis, Reduzir o Número de Animais Abandonados ,Fornecer Informações sobre os Animais, Promover a Conscientização, Apoiar Abrigos e Resgates, Facilitar o Processo de Adoção e Promover a Felicidade Animal. Além disso, pretendemos colocar uma função de denúncia de maus tratos aos animais, que visa proporcionar uma forma segura e eficaz para que indivíduos relatem e denunciem casos de crueldade,abuso ou negligência contra animais. Com isso temos a finalidade de combater a violência e o sofrimento infligidos aos animais, promovendo a conscientização, responsabilização e ação contra práticas prejudiciais. Nossos objetivos com isso são: Promover o Bem-Estar Animal, Conscientizar o Público, Coletar Evidências, Ajudar na  ntervenção Rápida, Facilitar a Denúncia Anônima, Fomentar a Responsabilização Legal e Apoiar Mudanças Legislativas.</p>
        
        <h2 id="comoPets"  class="conteirner-base-titulo2">COMO FUNCIONA O PETS ?</h2>
        <p class="conteirner-base-p2">O programa PetS é meio de pessoas conhecerem seus amigos de quatro patas: por meio do cadastro e a atuação de ONGs/protetores, vários gatos e cachorros podem ter a chance de encontrar seus novos melhores amigos. Adotar esses pequeninos é um momento importante e feliz, que deve ser levado com seriedade, responsabilidade e muito cuidado.Por meio do programa PetS as ONGs/protetores podem se cadastrar para que seus animais possam ser adotadas e encontrar um lar. A PetS disponibiliza o espaço para que essas adoções aconteçam em um lugar só.</p>
        
        <h2 id="comoAdotar"  class="conteirner-base-titulo3">COMO POSSO ADOTAR?</h2>
        <p class="conteirner-base-p3">Para realizar as adoções basta seguir os passos: </p>
            <p class="conteirner-base-p3-0">- Criar um perfil na PetS</p>
            <p class="conteirner-base-p3-1">- Encontrar seu melhor amigo</p>
            <p class="conteirner-base-p3-2">- Preencher o formulário</p>
            <p class="conteirner-base-p3-3">- Avaliação do Perfil</p> 
            <p class="conteirner-base-p3-4">- Adoção completa</p>
            
            <p class="conteirner-base-p3-5">Duvidas sobre a adoção? Sessão de Adoção</p>
    </div>

    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>
    
</body>
</html>