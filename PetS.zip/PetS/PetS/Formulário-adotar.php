<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de denúncia</title>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>


    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo/estilo-formulário-adotar.css">
</head>
<body>
    <header><nav>
        <!-- MENU -->
        <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>
<div class="container-formulário">
<h2 class="formulário-texto">Formulário para adoção</h2>

</div>
<div class="container-caixa">
    <p class="p1-descrição">A PetS disponibiliza um meio de adoção enviada por formulário e nossos assistente avaliam sua descrição e preparam os pets para sua retirada.</p>
    <h2 class="resumo">Nome do Pet*</h2>
    <p class="p2-descrição">Nos informe qual pet você gostaria de adotar</p>
    <input class="formulário-titulo" type="text">
    <h2 class="adocao">Informações sobre a adoção*</h2>
    <p class="p3-descrição">Nos fale data em que gostaria de ir busca-lo e por que gostaria de adota-lo.</p>
    <textarea class="formulário-descrição" cols="35" rows="8"></textarea>
    <a><button class="btn-enviar">Enviar</button></a>
    <a><button class="btn-cancelar">Cancelar</button></a>
</div>
    </header>
    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>
</body>
</html>