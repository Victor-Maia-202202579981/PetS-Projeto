<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de denúncia</title>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>


    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo/estilo-formulário-denunciar.css">
</head>
<body>
    <header><nav>
        <!-- MENU -->
        <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>
<div class="container-formulário">
<h2 class="formulário-texto">Formulário para denuncias</h2>

</div>
<div class="container-caixa">
    <p class="p1-descrição">A PetS disponibiliza um meio de denuncia enviada por formulário e nossos assistente verificam sua denuncia e assim após a verificação seguimos para as autoridades.</p>
    <h2 class="resumo">Resumo*</h2>
    <p class="p2-descrição">Coloque o ponto principal da sua denuncia</p>
    <input class="formulário-titulo" type="text">
    <h2 class="relato">Relato*</h2>
    <p class="p3-descrição">Coloque o seu relato inteiro e o mais claro possível.</p>
    <textarea class="formulário-descrição" cols="35" rows="8"></textarea>
    <p class="p4-descrição">Caso fique com duvidas, a PetS pede que entre esteja entrando em contato os seguintes números:</p>
    <p class="p5-descrição">• Disque Denúncia 0800-092-0500</p>
    <a class="informaçoes" href="Denunciar.html">Mais informações</a>
    <a><button class="btn-enviar">Enviar</button></a>
    <a><button class="btn-cancelar">Cancelar</button></a>
</div>
    </header>
    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>
</body>
</html>