<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ONGS/Protetores</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>


    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 
    <link rel="stylesheet" href="css/estilo/estilo-ongs.css">
</head>
<body>
    <header>
        <nav>
            <!-- MENU -->
            <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>
            
            <div class="conteiner-ongs">
                <h2 class="conteiner-ongs-titulo">Ongs/Protetores</h2>
                <p class="conteiner-ongs-titulo-paragrafo">O programa PetS tem parceira com as seguintes ONGS que disponibilizam a imagens de seus animais para adotar. Caso seja uma ONG interessada   em fazer parte da PetS por favor entrar em contato pelo e-mail pets@gmail.com e saiba mais sobre o processo de cadastramento.</p>
                
                <div class="card-ong-01">
                    <img class="card-ong-01-img" src="img/apam-logo.jpeg" alt="Logo APAM">
                    <h3>Associação Portal dos Anjos Manaus</h3>
                    <p>Endereço: Tv. Ouroeste, 2 - Aleixo, Manaus - AM, 69060-330</p>
                </div>

                <div class="card-ong-02">
                    <img src="img/ongs/img-cachorro-logo.png" alt="">
                    <h3>ONG Peludinhos</h3>
                    <p>Endereço: Avendia 2, 2 - Aleixo, Manaus - AM, 69060-300</p>
                </div>
            </div>
            
            <!-- RODAPÉ DA PÁGINA-->
            <div class="conteiner-buttom">
                <img src="img/logo/icone-rodape-logo.png" alt="">
                <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
                <h3>Institucional</h3>
                <h4 class="conteiner-item1">Sobre o PetS</h4>
                <h4 class="conteiner-item2">FAQ</h4>
            </div>
            
    </header>
    
</body>
</html>