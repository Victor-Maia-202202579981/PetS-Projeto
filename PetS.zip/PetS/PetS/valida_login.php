<?php session_start();

	require('conexao.php');


	if (isset($_POST['login_adotante'])) {      
	
		/* RECEBENDO OS DADOS VIA POST DO FORMULÁRIO */

		$email_adotante = $_POST['email_adotante'];
		$senha_login_adotante = md5($_POST['senha_login_adotante']);


		/* VALIDANDO OS DADOS NO TABELA LOGIN */
	
		$sql_valida_login = mysqli_query($conexao,"SELECT * FROM login_adotante WHERE email_adotante = '".$email_adotante."' AND senha_login_adotante = '".$senha_login_adotante."'");
		
		if(mysqli_num_rows($sql_valida_login) > 0){
	
			
			$_SESSION['nome_login'] = $registros_login['nome_login'];
			$_SESSION['tipo_login'] = $registros_login['tipo_login'];


			$_SESSION['url'] = $url;
			$_SESSION['url_admin'] = $url_admin;
					
			
				if($_SESSION['tipo_login'] == 0){

					echo "<script> alert('Administrador [LOGADO]');</script>";

					echo "<script> window.location.href='$url_admin';</script>";
					
				}else{

					echo "<script> alert('Aluno [LOGADO]');</script>";

					echo "<script> window.location.href='$url_aluno';</script>";

				}
			
		} else {

			echo "<script> alert('Erro ao fazer login. Tente novamente ou fale com o Administrador.');</script>";

			echo "<script> window.location.href='$url';</script>";
			
		}

	}

?> 