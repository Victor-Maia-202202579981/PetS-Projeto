<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Denuncias</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>

    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon">
    <link rel="stylesheet" href="css/estilo/estilo-denuncias.css">
</head>
<body>
    <header><nav>
        <!-- MENU -->
        <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>

        <div class="container-Denuncias">
            <h2 class="denuncia-texto">Denuncias</h2>
            <p>As denunciais são um dos meios de ajudar aqueles que não conseguem expressas suas dores e não podem pedir ajudar.</p>
            <h2  id="contatos-guia" class="container-contatos">Contatos</h2>
            <div class="ibama"> <h3>Ibama</h3>
            <p>As denúncias podem ser feitas pelo telefone 0800 61 8080 (gratuitamente) ou pelo email para linhaverde.sede@ibama.gov.br. O IBAMA (Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis) as encaminhará para a delegacia mais próxima do local da agressão.</p>
        </div>
        <div class="brasil"> <h3>Brasil</h3>
        <p class="p1-brasil">• Polícia Militar:190 </p>
        <p class="p2-brasil">• Disque Denúncia:181</p>
        <p class="p3-brasil">• IBAMA (no caso de animais silvestres) - Linha Verde: 0800 61 8080www.ibama.gov.br/denuncias</p>
        <p class="p4-brasil">• Ministério Público Federal: http://www.mpf.mp.br/servicos/sac        </p>            
        <p class="p5-brasil">• Safer Net (crimes de crueldade ou apologia aos maus-tratos na internet): www.safernet.org.br</p>
        </div>
        <div class="telefones"><h3>Telefones</h3></div>
        <div class="amazonas"><h2>Amazonas</h2>
        <p>• Disque Denúncia 0800-092-0500</p>
        </div>
        <div id="formulario-guia" class="formulario-denuncias"><h2>Formulário para Denuncias</h2>
        <p>A PetS disponibiliza um meio de denuncia enviada por formulário e nossos assistente verificam sua denuncia e assim após a verificação seguimos para as autoridades.</p>
        </div>
        <a href="Formulário-denunciar.html" class="formulario">Formulário.</a>
        
        <!-- GUIA -->
        <div class="container-guia">
                    <ul><h3>Guia</h3></ul>
                    <li><a href="#contatos-guia"><h4 class="guia-item1">Contatos</h4></a></li>                    
                    <li><a href="#formulario-guia"><h4 class="guia-item2">Formulário de denuncias</h4></a></li>
                </div>

    </header>

    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>
    


    
</body>
</html>