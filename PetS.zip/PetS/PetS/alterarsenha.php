<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar-senha</title>
    <!-- LOGO NA ABA DA PÁGINA -->
    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 
    <link rel="stylesheet" href="css/estilo/estilo-alterarsenha.css">
</head>
<body>
    <header><nav>
            <!-- MENU -->
                <ul class="menu">
                    <li><a class="logo" src="index.php">PetS</a></li>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="institucional.php">Institucional</a></li>
                    <li><a href="ongs.php">ONGs/Potetores</a></li>
                    <li><a href="Denunciar.php">Denunciar</a></li>
                </ul>
                <a><button class="btn-adotar">Adotar</button></a>
                <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
            </nav>
    <header>
        
        </div>
        <div class="container-fundo"></div>
        <div class="container-caixa1">
            <h1 class="alterar-senha">Alterar senha</h1>
            <br><br>
            <p class="senha-atual">Senha atual</p>
            <input class="senha-atual" type="text">
            <br><br>
            <p class="nova-senha"> Nova senha</p>
            <input class="nova-senha" type="text">
            <br><br>
            <p class="confirmar-senha">Confirmar a senha</p>
            <input class="confirmar-senha" type="text">
            <a><button class="btn-cancelar">Cancelar</button></a>
            <a><button class="btn-atualizar">Atualizar</button></a>
</body>
</html>