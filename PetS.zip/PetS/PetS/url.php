<?php

	$host_ip = $_SERVER['HTTP_HOST'];

	$url = "http://".$host_ip."/portal/";

	$url_admin = $url."admin";

?>
