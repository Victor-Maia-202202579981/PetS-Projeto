-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13-Mar-2023 às 23:25
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_portal`
--
DROP DATABASE IF EXISTS `db_pets`;
CREATE DATABASE IF NOT EXISTS `db_pets` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_petsl`;
-- --------------------------------------------------------

--
-- Banco de dados: `ong`
--
CREATE TABLE `ong` (
    `cnpj` VARCHAR(100),
    `email` VARCHAR(200) UNIQUE,
    `senha` VARCHAR(100)
);
-- --------------------------------------------------------


--
-- Banco de dados: `adotante`
--
CREATE TABLE `adotante` (
    `cpf_adotante` CHAR(11) PRIMARY KEY,
    `email` VARCHAR(200) UNIQUE,
    `senha` VARCHAR(100)
);

CREATE TABLE `animal` (
    id_animal INT AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(20),
    `especie` VARCHAR(200),
    `cnpj_ong` CHAR(14)
);

CREATE TABLE `adocao` (
    id_adocao INT AUTO_INCREMENT PRIMARY KEY,
    `resumo` VARCHAR(100),
    `dt_adocao` varchar(10)
);

CREATE TABLE `denuncia` (
    `descricao` VARCHAR(100),
    `resumo` VARCHAR(50)
);

--
-- Estrutura da tabela `login-adotante`
--

CREATE TABLE `login_adotante` (
  `email_adotante` varchar(50) NOT NULL,
  `senha_login_adotante` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login_adotante` (`email_adotante`,`senha_login_adotante` ) VALUES
('maria123@gmail.com', 'maria123'),
('joao456@gmail.com', 'joao456');
--
-- Estrutura da tabela `login-adotante`
--

CREATE TABLE `login_ong` (
  `cnpj_ong` varchar(15) NOT NULL,
  `senha_login_ong` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login_ong` (`cnpj_ong`,`senha_login_ong` ) VALUES
('528789445000123', '528789445000123'),
('123456789000123', '123456789000123');
--
