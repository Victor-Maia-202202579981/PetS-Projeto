<!DOCTYPE html>

<!-- LÍNGUA DA PÁGINA -->
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=News+Cycle:wght@400;700&family=Roboto+Condensed:wght@300;400&display=swap');
    </style>
    <!-- NOME DO SITE NA ABA DA PÁGINA -->
    <title>PetS - Adotar Animais</title>

    <link rel="stylesheet" href="css/estilo/reset-css.css">

    <!-- BUSCANDO O ESTILO DO SITE NO ESTILO.CSS -->
    <link rel="stylesheet" href="css/estilo/estilo.css">

    <!-- LOGO NA ABA DA PÁGINA -->
    <link rel="shortcut icon" href="img/logo/icone-top-aba.png" type="image/x-icon"> 

</head>
<body>
    <header>
         <!-- LOGO NO CORPO DA PÁGINA 
        <div class="logo">
            <img src="img/icone-letra.png" alt="Logo tipo PetS">
        </div>-->

<!-- NAVEGABILIDADE- USUÁRIO PODE ACESSAR OUTRAS ABAS -->
        <nav>
        <!-- MENU -->
            <ul class="menu">
                <li><a class="logo" src="index.php">PetS</a></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="institucional.php">Institucional</a></li>
                <li><a href="ongs.php">ONGs/Potetores</a></li>
                <li><a href="Denunciar.php">Denunciar</a></li>
            </ul>
            <a href="adotar.php"><button class="btn-adotar">Adotar</button></a>
            <a href="Logar.php"><button class="btn-entrar">Entrar</button></a>
        </nav>

<!-- imagem da home principal -->
        <div class="imagem-home">
            <img src="img/home-img/imagem-home.png" alt="Home Imagem">
        </div>

<!-- texto1 -->
        <div class="texto-ja">
            <h2>Já deu uma olhada nessas fofuras?</h2>
            <a href="adotar.php"><h2 class="texto-ja-adotar">Vê mais</h2></a>
        </div>

 <!-- CONTENER DOS ANIMAIS -->
        <div class="container-animal-adotacao">
            <div class="card">
                <div class="imgBx">
                    <a href="#">
                    <img class="imgBx1" src="img/home-img/Imagem-Home-exemplo1.jpg" alt="">
                    </a>
                    <p>ONG Peludinhos - AM</p>
                    <h3><br> Pipoca, feminino</h3>
                    <p>Manaus, AM </p>
                </div>
            </div>
            <div class="card">
                <div class="imgBx">
                    <a href="#">
                    <img class="imgBx2" src="img/home-img/imagem-home-exemplo2.jpeg" alt="">
                    </a>
                    <p>Maria Fátima - AM</p>
                    <h3><br> Mel, feminino</h3>
                    <p>Manaus, AM </p>
                </div>
            </div>
            <div class="card">
                <div class="imgBx">
                    <a href="#">
                    <img class="imgBx3" src="img/home-img/imagem-home-exemplo3.jpeg" alt="">
                    </a>
                    <p>ONG CATS LOVERS- AM</p>
                    <h3><br>Rosa, Perola e Nana, Feminino</h3>
                    <p>Manaus, AM </p>
                </div>
            </div>
        </div>
<!-- texto1 -->
<div class="texto-texto2">
    <h2>Gostaria de adotar? E não sabe por onde começar?</h2>
</div>

 <!-- COINENER DOS ANIMAIS -->
 <div class="container-passo">
    <div class="card-passo">
        <div class="imgBx-passo">
            <a href="#">
            <img class="imgBx1-passo" src="img/home-img/icone-ache-pet.png" alt="">
            </a>
            <h3><br> Ache seu pet</h3>
            <p>Por meio da nossa lista de fofuras disponíveis, pode escolher um pet para chamar de seu.</p>
        </div>
    </div>

    <div class="card-passo2">
        <div class="imgBx-passo2">
            <a href="#">
            <img class="imgBx1-passo2" src="img/home-img/icone-criar-perfil.png" alt="">
            </a>
            <h3><br>Criar um perfil</h3>
            <p>Conte um pouco sobre você, sua familía e o local oande mora. </p>
        </div>
    </div>
    <div class="card-passo3">
        <div class="imgBx-passo3">
            <a href="#">
            <img class="imgBx1-passo3" src="img/home-img/icone-verificar-perfil.png" alt="">
            </a>
            <h3><br>Avaliação do Perfil</h3>
            <p>Nesta etapa a ONG ou o responsável pelo pet irá verificar suas resposta no formulário.</p>
        </div>
    </div>
    <div class="card-passo4">
        <div class="imgBx-passo4">
            <a href="#">
            <img class="imgBx1-passo4" src="img/home-img/icone-adocao-pet.png" alt="">
            </a>
            <h3><br>Adoção completa</h3>
            <p>Após validar as informações, pode se dirigir até a ONG para buscar o seu novo amigo pet.</p>
        </div>
    </div>
</div>

    <div class="container-denuncias">
        <h2>Dúvidas sobre as Denunciais?</h2>
        <p>Na área de Denunciais, você pode encontrar o guia para realizar a denuncia via formulário ou contato/local para realizar a denuncia.</p>
        <button>Denunciar</button>
    </div>

    <!-- RODAPÉ DA PÁGINA-->
    <div class="conteiner-buttom">
        <img src="img/logo/icone-rodape-logo.png" alt="">
        <p>A PetS é um programa criado para facilitar o encontro seu amigo de quatro patas. Sendo através de ONG ou responsável do pet.</p>
        <h3>Institucional</h3>
        <h4 class="conteiner-item1">Sobre o PetS</h4>
        <h4 class="conteiner-item2">FAQ</h4>
    </div>

    </header>

    <main>
        
    </main>
</body>
</html>